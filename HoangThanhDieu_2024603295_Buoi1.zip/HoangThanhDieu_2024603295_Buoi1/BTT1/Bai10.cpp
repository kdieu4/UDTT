﻿#include <iostream>
#define MAX 100
using namespace std;
/*
Cài đặt chương trình tính tổng các số lẻ trong một dãy n số nguyên bằng
đệ quy.
*/

int solve(int x[], int n) {
	if (n == 0) return 0;
	if (x[n] % 2 != 0) {
		return solve(x, n - 1) + x[n];
	}
	return solve(x, n - 1);
}

int main() {
	int x[MAX], n;
	cout << "Nhap so luong phan tu: ";
	cin >> n;
	cout << "Nhap day so gom n phan tu: ";
	for (int i = 1; i <= n; i++) {
		cin >> x[i];
	}
	cout << "Tong cac so le: " << solve(x, n);
	return 0;
}