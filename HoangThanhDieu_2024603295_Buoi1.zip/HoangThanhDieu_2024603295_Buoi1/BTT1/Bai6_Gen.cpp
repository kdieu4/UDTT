﻿#include <iostream>
#define MAX 100
using namespace std;
/*
Cài đặt chương trình liệt kê tất cả các cách xếp 6 sinh viên gồm: Trang,
Cong, Trung, Binh, Hoan, Mai vào 6 chiếc ghế được đánh số thứ tự 1, 2, ..., 6.
theo thuat toan sinh
*/
string name[] = { "", "Trang", "Cong", "Trung", "Binh", "Hoan", "Mai" };
int dd[MAX];

void swap(int& a, int& b) {
	int tmp = a;
	a = b;
	b = tmp;
}

void view_config(int x[], int n) {
	for (int i = 1; i <= 6; i++) {
		cout << name[x[i]] << " ";
	}
	cout << endl;
}

void next_config(int x[], int n, int i) {
	int k = n;
	while (x[k] < x[i]) {
		k--;
	}
	swap(x[i], x[k]);
	int j = n; i++;
	while (i < j) {
		swap(x[i], x[j]);
		i++;
		j--;
	}
}

void list_configs(int n) {
	int x[MAX];
	for (int i = 1; i <= n; i++) {
		x[i] = i;
	}
	int i;
	do {
		view_config(x, n);
		i = n - 1;
		while (i > 0 && x[i] > x[i + 1]) {
			i--;
		}
		if (i > 0) {
			next_config(x, n, i);
		}

	} while (i > 0);
}

int main() {
	cout << "Cac cach sap xep 6 sv duoc danh so vao 6 chiec ghe: \n";
	list_configs(6);
	return 0;
}