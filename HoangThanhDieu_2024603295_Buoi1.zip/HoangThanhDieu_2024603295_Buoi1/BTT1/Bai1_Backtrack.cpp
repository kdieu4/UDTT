﻿#include <iostream>
#define MAX 100

using namespace std;

//Cài đặt chương trình sinh các chuỗi nhị phân có độ dài n bằng phương pháp quay lui

void show(int x[], int n) {
	for (int i = 1; i <= n; i++) {
		cout << x[i];
	}
	cout << endl;
}

void Try(int x[], int k, int n) {
	for (int i = 0; i <= 1; i++) {
		x[k] = i;
		if (k == n) {
			show(x, n);
		}
		else {
			Try(x, k + 1, n);
		}
	}
}

int main() {
	int n;
	cout << "Nhap do dai xau nhi phan: ";
	cin >> n;
	int x[100];
	Try(x, 1, n);
	return 0;
}