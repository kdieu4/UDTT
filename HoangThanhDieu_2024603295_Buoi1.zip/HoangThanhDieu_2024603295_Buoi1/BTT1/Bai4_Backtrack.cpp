#include <iostream>
#include <string>
#define MAX 100
using namespace std;

string name[] = { "","Trang", "Cong", "Trung", "Binh", "Hoan", "Mai" };
int n = 6, k = 4;
int x[MAX];

void show() {
	for (int i = 1; i <= k; i++) {
		cout << name[x[i]] << " ";
	}
	cout << endl;
}

void Try(int index) {
	for (int i = 1; i <= n; i++) {
		if (i > x[index - 1]) {
			x[index] = i;
			if (index == k) {
				show();
			}
			else {
				Try(index + 1);
			}
		}
	}
}

int main() {
	//cin >> n >> k;
	Try(1);
	return 0;
}