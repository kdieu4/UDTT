#include <iostream>
#define MAX 100
using namespace std;

int cnt = 1, m, n;
int  O[MAX][MAX];
bool flag[MAX][MAX];
int dx[] = { 0, -1, 0, 1 };
int dy[] = { -1, 0, 1, 0 };

void show() {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cout << O[i][j] << " ";
		}
		cout << endl;
	}
}

/*
1 1 0 0 0 1
1 0 0 0 0 0
1 0 0 1 1 0
0 1 1 0 0 1
0 0 1 0 1 1 
*/

void flood_fill(int i, int j) {
	flag[i][j] = true;
	if (j > 0) 
		if (O[i][j - 1] == O[i][j] && !flag[i][j - 1]) 
			flood_fill(i, j - 1);
	if (i > 0)
		if (O[i - 1][j] == O[i][j] && !flag[i - 1][j])
			flood_fill(i - 1, j);
	if (j < n)
		if (O[i][j + 1] == O[i][j] && !flag[i][j + 1])
			flood_fill(i, j + 1);
	if (i < m)
		if (O[i + 1][j] == O[i][j] && !flag[i + 1][j])
			flood_fill(i + 1, j);
}

int main() {
	cin >> m >> n;
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			cin >> O[i][j];
			flag[i][j] = 0;
		}
	}
	
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			if (!flag[i][j]) {
				flood_fill(i, j);
				cnt++;
			}
		}
	}
	cout << cnt;
	
	return 0;
}