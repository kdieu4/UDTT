#include <iostream>

using namespace std;

int tinhTong(int n) {
	if (n > 0 && n < 9) {
		return n;
	}
	return tinhTong(n / 10) + n%10;
}

int main() {
	int n;
	cout << "Nhap so nguyen duong n: ";
	cin >> n;
	cout << "Tong chu so: " << tinhTong(n);
	return 0;
}