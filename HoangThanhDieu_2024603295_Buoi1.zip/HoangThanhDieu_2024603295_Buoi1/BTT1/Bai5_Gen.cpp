﻿//#include <iostream>
//#define MAX 100
//using namespace std;
///*
//Cài đặt chương trình sinh các hoán vị của tập S = {1, 2, ..., n} 
//bang thuat toan sinh.
//*/
//
//void swap(int& a, int& b) {
//	int tmp = a;
//	a = b;
//	b = tmp;
//}
//
//void view_config(int x[], int n) {
//	for (int i = 1; i <= n; i++) {
//		cout << x[i];
//	}
//	cout << endl;
//}
//
//void next_config(int x[], int n, int i) {
//	// tim x[k] be nhat trong foan cuoi lon hon x[i]
//	int k = n;
//	while (x[k] < x[i]) {
//		k--;
//	}
//	// dao gia tri x[i] va x[k]
//	swap(x[i], x[k]);
//	// dap nguoc doan cuoi
//	int j = n; i++;
//	while (i < j) {
//		swap(x[i], x[j]);
//		i++;
//		j--;
//	}
//
//}
//
//void list_configs(int n) {
//	// sinh cau hinh dau tien 1 2 ... n
//	// cau hinh cuoi n n-1 ... 1
//	int x[MAX] = {0};
//	for (int i = 1; i <= n; i++) {
//		x[i] = i;
//	}
//	// lap
//	int i = 0;
//	do {
//		view_config(x, n);
//		i = n - 1;
//		while (i > 0 && x[i] > x[i + 1]) {
//			i--;
//		}
//		if (i > 0) {
//			next_config(x, n, i);
//		}
//	} while (i > 0);
//}
//
////int main() {
////	int n;
////	cin >> n;
////	list_configs(n);
////	return 0;
////}