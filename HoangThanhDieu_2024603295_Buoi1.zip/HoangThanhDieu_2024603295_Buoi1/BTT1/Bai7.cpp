#include <iostream>
#define MAX 100

using namespace std;

long long* f = new long long[MAX];
long long findFibonacci(int n) {
	if (n == 0 || n == 1) {
		f[n] = 1;
	}
	else if (f[n] < 0) {
		f[n] = findFibonacci(n - 1) * n;
	}
	return f[n];
}

int main() {
	int n;
	cout << "Nhap n: ";
	cin >> n;
	cout << findFibonacci(n);
	return 0;
}