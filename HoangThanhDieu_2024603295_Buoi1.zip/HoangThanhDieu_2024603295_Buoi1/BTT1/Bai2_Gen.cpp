#include <iostream>
#define MAX 100
using namespace std;

void view_config(char x[], int n) {
	for (int i = 1; i <= n; i++) {
		cout << x[i];
	}
	cout << endl;
}

void next_config(char x[], int i, int n) {
	x[i] = 'b';
	i++;
	while (i <= n) {
		x[i] = 'a';
		i++;
	}
}

void list_configs(int n) {
	int i;
	char x[MAX];
	for (int i = 1; i <= n; i++) {
		x[i] = 'a';
	}
	do {
		view_config(x, n);
		i = n;
		while (i > 0 && x[i] == 'b') {
			i--;
		}
		if (i > 0) {
			next_config(x, i, n);
		}
	} while (i > 0);
}

//int main() {
//	int n;
//	cout << "Nhap do dai chuoi ky tu: ";
//	cin >> n;
//	list_configs(n);
//	return 0;
//}