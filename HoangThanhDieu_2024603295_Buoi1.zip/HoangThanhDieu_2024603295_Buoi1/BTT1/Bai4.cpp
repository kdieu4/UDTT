﻿//#include <iostream>
//#include <string>
//#define MAX 100
//
//using namespace std;
//
///*
//Cài đặt chương trình liệt kê các cách lấy 4 sinh viên từ 6 sinh viên gồm:
//Trang, Cong, Trung, Binh, Hoan, Mai bang thuat toan sinh.
//Trang Cong Trung Binh Hoan Mai
//*/
//
//string name[] = { "","Trang", "Cong", "Trung", "Binh", "Hoan", "Mai" };
//int n = 6;
//int k = 4;
////int n, k;
////string name [MAX];
//
//void view_config(int x[]) {
//	for (int i = 1; i <= k; i++) {
//		cout << name[x[i]] << " ";
//	}
//	cout << endl;
//}
//
//void next_config(int x[], int i) {
//	x[i] ++;
//	i++;
//	while (i <= k) {
//		x[i] = x[i - 1] + 1;
//		i++;
//	}
//}
//
//void list_configs() {
//	int x[MAX];
//	int i, j;
//	for (int i = 1; i <= k; i++) {
//		x[i] = i;
//	}
//	do {
//		view_config(x);
//		i = k; j = i;
//		while (i > 0 && x[i] == n - k + i) {
//			i--;
//		}
//		if (i > 0) {
//			next_config(x, i);
//		}
//	} while (i > 0);
//}
//
//int main() {
//	/*cin >> n >> k;*/
//
//	/*for (int i = 1; i <= n; i++) {
//		cin >> name[i];
//	}
//	for (int i = 1; i <= n; i++) {
//		cout << name[i] << " ";
//	}*/
//	list_configs();
//	return 0;
//}