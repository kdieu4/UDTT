﻿#include <iostream>
#define MAX 100
using namespace std;
/*
Bài tập 3: Cài đặt chương trình sinh 
các tập con k phần tử của tập S = {1, 2, ..., n} bang thuat toan sinh.
*/

void view_config(int x[], int n) {
	for (int i = 1; i <= n; i++) {
		cout << x[i];
	}
	cout << endl;
}

void next_config(int x[], int i, int k) {
	x[i]++;
	i++;
	while (i <= k) {
		x[i] = x[i - 1] + 1;
		i++;
	}
}

void list_configs(int n, int k) {
	int x[MAX];
	int i;
	for (int i = 1; i <= k; i++) {
		x[i] = i;
	}
	do {
		view_config(x, k);
		i = k;
		while (i > 0 && x[i] == n - k + i) {
			i--;
		}
		if (i > 0) {
			next_config(x, i, k);
		}
	} while (i > 0);
}

int main() {
	int n, k;
	cin >> n >> k;
	list_configs(n, k);
	return 0;
}