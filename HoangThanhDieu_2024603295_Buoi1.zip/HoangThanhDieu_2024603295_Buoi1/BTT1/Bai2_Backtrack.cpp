﻿#include <iostream>
#define MAX 100
using namespace std;
/*
Cài đặt chương trình sinh các chuỗi ký tự độ dài chỉ chứa 2 ký tự ‘a’ và
ký tự ‘b’ bang thuat toan quay lui.
*/

void show(char x[], int n) {
	for (int i = 1; i <= n; i++) {
		cout << x[i];
	}
	cout << endl;
}

void Try(char x[], int k, int n, char value[]) {
	for (int i = 0; i <= 1; i++) {
		x[k] = value[i];
		if (k == n) {
			show(x, n);
		}
		else {
			Try(x, k + 1, n, value);
		}
	}
}

int main() {
	int n;
	cout << "Nhap do dai xau ky tu: ";
	cin >> n;
	char x[MAX];
	char value[] = { 'a', 'b' };
	Try(x, 1, n, value);
	return 0;
}
