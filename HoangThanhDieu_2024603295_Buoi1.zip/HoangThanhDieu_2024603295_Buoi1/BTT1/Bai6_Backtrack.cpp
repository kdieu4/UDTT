﻿#include <iostream>
#define max 100
using namespace std;
/*
cài đặt chương trình liệt kê tất cả các cách xếp 6 sinh viên gồm: trang,
cong, trung, binh, hoan, mai vào 6 chiếc ghế được đánh số thứ tự 1, 2, ..., 6.
theo thuat toan quay lui
*/
string name[] = { "", "trang", "cong", "trung", "binh", "hoan", "mai" };
int x[max], dd[max], n = 6;

void show() {
	for (int i = 1; i <= n; i++) {
		cout << name[x[i]] << " ";
	}
	cout << endl;
}

void Try(int k) {
	for (int i = 1; i <= n; i++) {
		if (dd[i] == 0) {
			x[k] = i;
			if (k == n) {
				show();
			}
			else {
				dd[i] = 1;
				Try(k + 1);
				dd[i] = 0;
			}
		}
	}
}

int main() {
	cout << "cac cach sap xep 6 sv duoc danh so vao 6 chiec ghe: \n";
	Try(1);
	return 0;
}