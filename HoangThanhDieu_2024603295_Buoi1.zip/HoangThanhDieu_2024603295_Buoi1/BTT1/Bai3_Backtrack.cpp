﻿#include <iostream>
using namespace std;

#define MAX 100

/*
Cài đặt chương trình sinh các tập con k phần tử của
tập S = {1, 2, ..., n} bang thuat toan quay lui.
*/

int n, k;
int x[MAX], dd[MAX];

void show() {
	for (int i = 1; i <= k; i++) {
		cout << x[i];
	}
	cout << endl;
}

void Try(int index) {
	for (int i = 1; i <= n; i++) {
		if (i > x[index - 1]) {
			x[index] = i;
			if (index == k) {
				show();
			}
			else {
				dd[i] = 1;
				Try(index + 1);
				dd[i] = 0;
			}
		}
	}
}

//int main() {
//	cin >> n >> k;
//	Try(1);
//	return 0;
//}