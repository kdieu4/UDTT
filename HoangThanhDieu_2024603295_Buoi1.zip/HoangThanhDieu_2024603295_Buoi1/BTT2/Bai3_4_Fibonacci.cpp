﻿#include <iostream>
#define MAX 100
using namespace std;

/*
Cài đặt bài toán tìm số fibonaci theo thuật toán đệ quy
*/

long long fibonacci(int n) {
	if (n == 1 || n == 2) {
		return 1;
	}
	else return fibonacci(n - 1) + fibonacci(n - 2);
}

long long fibonacci_loop(int n) {
	long long f[MAX] = { 0 };
	f[1] = f[2] = 1;
	for (int i = 3; i <= n; i++) {
		f[i] = f[i - 1] + f[i - 2];
	}
	return f[n];
}

int main() {
	int n;
	cout << "Nhap n: "; cin >> n;
	cout << "De quy: f(n) = " << fibonacci(n) << endl;
	cout << "Lap: f(n) = " << fibonacci_loop(n) << endl;
	return 0;
}