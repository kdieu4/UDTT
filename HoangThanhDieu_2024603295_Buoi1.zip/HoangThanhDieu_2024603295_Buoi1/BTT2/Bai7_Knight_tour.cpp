﻿#include <iostream>
#include <vector>
using namespace std;

//Cài đặt bài toán mã đi tuần theo phương pháp quay lui

int dx[] = { 0, 2, 1, -1, -2, -2, -1, 1, 2 };
int dy[] = { 0, 1, 2, 2, 1, -1, -2, -2, -1 };

bool isSafe(int x, int y, int n, vector <vector<int>> & board){
	return (x > 0 && y > 0 && x <= n && y <= n && board[x][y] == -1);
}

bool knightTourUtil(int x, int y, int step, int n, vector<vector<int>>& board) {
	if (step > n * n) {
		return true;
	}
	for (int i = 1; i <= 8; i++) { // chon nuoc di tiep tu danh sach
		int nx = x + dx[i];
		int ny = y + dy[i];
		if (isSafe(nx, ny, n, board)) {  // chap nhan duoc
			board[nx][ny] = step;  // ghi nho nuoc di
			if (knightTourUtil(nx, ny, step + 1, n, board)) {  // di nuoc tiep theo ban co da kin
				return true;
			}
			board[nx][ny] = -1;  // xoa ghi nho truoc
		}
	}
	return false;
}

vector <vector<int>> knightTour(int n) {
	vector <vector<int>> board(n + 1, vector<int>(n + 1, -1));
	board[1][1] = 1;
	if (knightTourUtil(1, 1, 2, n, board)) {
		return board;
	}
	return { {-1} };
}

int main() {
	int n;
	cout << "Nhap kich thuoc n cua ban co n: ";
	cin >> n;
	vector <vector<int>> res = knightTour(n);
	/*for (auto& row : res) {
		for (int val : row) {
			cout << val << " ";
		}
		cout << endl;
	}*/
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			cout << res[i][j] << " ";
		}
		cout << endl;
	}
	return 0;
}