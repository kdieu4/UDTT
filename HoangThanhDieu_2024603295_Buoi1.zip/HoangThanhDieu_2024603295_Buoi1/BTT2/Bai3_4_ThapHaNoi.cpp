﻿#include <iostream>
#include <stack>
using namespace std;

/*
Cài đặt bài toán tháp Hà Nội theo thuật toán đệ quy
*/

void chuyen(int n, char a, char b, char c) {
	if (n == 1) {
		cout << "Chuyen 1 dia tu " << a << " sang " << b << "\n";
	}
	else {
		chuyen(n - 1, a, c, b);
		chuyen(1, a, b, c);
		chuyen(n - 1, c, b, a);
	}
}

// Cài đặt bài toán tháp Hà Nội bang vong lap

struct Frame {
	int n;
	char a, b, c;
};

void Chuyen(int n, char a, char b, char c) {
	stack <Frame > s;
	s.push({ n, a, b, c });
	while (!s.empty()) {
		Frame cur = s.top();
		s.pop();
		if (cur.n == 1) {
			cout << "Chuyen 1 dia tu " << cur.a << " sang " << cur.b << endl;
		}
		else {
			s.push({ cur.n - 1, cur.c, cur.b, cur.a });
			s.push({ 1, cur.a, cur.b, cur.c });
			s.push({ cur.n - 1, cur.a, cur.c, cur.b });
		}
	}
}

int main() {
	int n;
	cout << "Nhap so dia can chuyen: ";
	cin >> n;
	cout << "Dung de quy: \n";
	chuyen(n, 'a', 'b', 'c');
	cout << "Dung vong lap: \n";
	Chuyen(n, 'a', 'b', 'c');
	return 0;
}