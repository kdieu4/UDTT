﻿#include <iostream>

using namespace std;
/*
Cài đặt bài toán tìm ước số chung lớn nhất 
theo thuật toán đệ quy
*/


int UCLN(int a, int b) {
	if (a % b == 0) return b;
	else return UCLN(b, a % b);
}

//Cài đặt bài toán tìm ước số chung lớn nhất theo thuật toán lặp (khử đệ quy)

int ucln(int a, int b) {
	int r = a % b;
	while (r > 0) {
		a = b; b = r;
		r = a % b;
	}
	return b;
}

int main() {
	int a, b;
	cout << "Nhap a, b: ";
	cin >> a >> b;
	cout << "De quy: UCLN (" << a << ", " << b << "): " << UCLN(a, b) << endl;
	cout << "Lap: UCLN (" << a << ", " << b << "): " << ucln(a, b);
	return 0;
}