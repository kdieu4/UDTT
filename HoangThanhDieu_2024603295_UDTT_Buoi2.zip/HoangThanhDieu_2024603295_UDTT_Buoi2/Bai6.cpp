#include <iostream>
#include <vector>

using namespace std;
/*
Cài đặt chương trình thực hiện.
- Khởi tạo danh sách a gồm tối thiểu 20 số nguyên.
- Tìm số chẵn nhỏ nhất trong danh sách a bằng một thuật toán được thiết kế
theo chiến lược chia để trị.
- Hiển thị kết quả.
*/

const double INFINITY = 1e9;

double evenMin(vector<double> a, int left, int right)
{
    if (left == right)
    {
        // return (static_cast<int>(a[left]) % 2 == 0) ? a[left] : INFINITY;
        return ((int)(a[left]) % 2 == 0) ? a[left] : INFINITY;
    }
    int mid = left + (right - left) / 2;
    return min(evenMin(a, left, mid), evenMin(a, mid + 1, right));
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    vector<double> a = {5, -3, 2.5, -1.5, 4, -6, 7.2, -8.3, 9, -10, 11.1, -12.2, 13.3, -14.4, 15.5, -16.6, 17.7, -18.8, 19.9, -20};
    cout << "Danh sach a: ";
    for (double num : a)
    {
        cout << num << " ";
    }
    cout << endl;
    // Chia để trị để tìm số chẵn nhỏ nhất
    cout << "So chan nho nhat trong danh sach a: " << evenMin(a, 0, a.size() - 1) << endl;
    return 0;
}