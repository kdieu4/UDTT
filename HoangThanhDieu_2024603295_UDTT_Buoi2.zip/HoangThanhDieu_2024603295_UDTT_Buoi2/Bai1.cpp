#include <iostream>
#include <vector>
#include <iomanip>
#include <numeric>
#include <algorithm>
using namespace std;

/*
Bài 1: Cho danh sách n học sinh, thông tin về mỗi học sinh gồm tên, họ đệm, năm
sinh, địa chỉ. Cài đặt chương trình thực hiện.
- Khởi tạo danh sách gồm tối thiểu 6 học sinh, sắp xếp danh sách học sinh theo
tên với thứ tự từ điển bằng một thuật toán sắp xếp có độ phức tạp O(nlgn).
- Nhập tên của một học sinh, tìm vị trí xuất hiện của học sinh này trong danh
sách theo chiến lược chia để trị, hiển thị thông tin đầy đủ của học sinh nếu tìm
được (nếu danh sách có nhiều học sinh trùng tên chỉ cần hiển thị thông tin của
học sinh tìm thấy đầu tiên).
*/

struct HocSinh
{
    string hoDem;
    string ten;
    int namSinh;
    string diaChi;
};

void nhap(vector<HocSinh> danhSachHS, int n)
{
    for (int i = 0; i < n; i++)
    {
        HocSinh hs;
        cout << "Nhap ho dem: ";
        cin >> hs.hoDem;
        cout << "Nhap ten: ";
        cin >> hs.ten;
        cout << "Nhap nam sinh: ";
        cin >> hs.namSinh;
        cout << "Nhap dia chi: ";
        cin >> hs.diaChi;
        danhSachHS.push_back(hs);
    }
}

void xuat(vector<HocSinh> danhSachHS)
{
    cout << setw(5) << "STT";
    cout << setw(15) << "Ho dem";
    cout << setw(15) << "Ten";
    cout << setw(15) << "Nam sinh";
    cout << setw(15) << "Dia chi" << endl;
    for (int i = 0; i < danhSachHS.size(); i++)
    {
        cout << setw(5) << i + 1;
        cout << setw(15) << danhSachHS[i].hoDem;
        cout << setw(15) << danhSachHS[i].ten;
        cout << setw(15) << danhSachHS[i].namSinh;
        cout << setw(15) << danhSachHS[i].diaChi << endl;
    }
    cout << endl;
}

void nhapSan(vector<HocSinh> &danhSachHS)
{
    HocSinh hs1 = {"Nguyen Van", "An", 2005, "Ha Noi"};
    HocSinh hs2 = {"Le Thi", "Binh", 2006, "TPHCM"};
    HocSinh hs3 = {"Tran Van", "Cuong", 2005, "Da Nang"};
    HocSinh hs4 = {"Pham Thi", "Duyen", 2007, "Hue"};
    HocSinh hs5 = {"Hoang Van", "An", 2006, "TPHCM"};
    HocSinh hs6 = {"Vu Thi", "Hoa", 2005, "Nghe An"};
    danhSachHS.push_back(hs1);
    danhSachHS.push_back(hs2);
    danhSachHS.push_back(hs3);
    danhSachHS.push_back(hs4);
    danhSachHS.push_back(hs5);
    danhSachHS.push_back(hs6);
}

void mergeSort(vector<HocSinh> &danhSachHS, int left, int right)
{
    if (left < right)
    {
        int mid = left + (right - left) / 2;
        mergeSort(danhSachHS, left, mid);
        mergeSort(danhSachHS, mid + 1, right);

        vector<HocSinh> temp = danhSachHS;
        // cout << "Danh sach tam thoi: " << endl;
        // xuat(temp);
        int i = left, j = mid + 1, k = left;
        while (i <= mid && j <= right && k <= right)
        {
            if (temp[i].ten < temp[j].ten)
            {
                danhSachHS[k++] = temp[i++];
            }
            else
            {
                danhSachHS[k++] = temp[j++];
            }
        }
        while (i <= mid)
        {
            danhSachHS[k++] = temp[i++];
        }
        while (j <= right)
        {
            danhSachHS[k++] = temp[j++];
        }
    }
}

int binarySearch(vector<HocSinh> danhSachHS, string tenCanTim)
{
    int left = 0, right = danhSachHS.size() - 1;
    while (left <= right)
    {
        int mid = left + (right - left) / 2;
        if (danhSachHS[mid].ten == tenCanTim)
        {
            return mid;
        }
        else if (danhSachHS[mid].ten < tenCanTim)
        {
            left = mid + 1;
        }
        else
        {
            right = mid - 1;
        }
    }
    return -1;
}

void timKiem(vector<HocSinh> danhSachHS)
{
    string tenCanTim;
    cout << "Nhap ten hoc sinh can tim: ";
    cin >> tenCanTim;
    int index = binarySearch(danhSachHS, tenCanTim);
    if (index != -1){
        cout << "Thong tin hoc sinh tim thay: " << endl;
        cout << setw(5) << "STT";
        cout << setw(15) << "Ho dem";
        cout << setw(15) << "Ten";
        cout << setw(15) << "Nam sinh";
        cout << setw(15) << "Dia chi" << endl;
        cout << setw(5) << index + 1;
        cout << setw(15) << danhSachHS[index].hoDem;
        cout << setw(15) << danhSachHS[index].ten;
        cout << setw(15) << danhSachHS[index].namSinh;
        cout << setw(15) << danhSachHS[index].diaChi << endl;
    }
    else
    {
        cout << "Khong tim thay hoc sinh co ten " << tenCanTim << endl;
    }
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    vector<HocSinh> danhSachHS;
    nhapSan(danhSachHS);
    cout << "Danh sach hoc sinh vua nhap la: " << endl;
    xuat(danhSachHS);
    cout << "Danh sach hoc sinh sau khi sap xep la: " << endl;
    mergeSort(danhSachHS, 0, danhSachHS.size() - 1);
    xuat(danhSachHS);

    timKiem(danhSachHS);

    return 0;
}