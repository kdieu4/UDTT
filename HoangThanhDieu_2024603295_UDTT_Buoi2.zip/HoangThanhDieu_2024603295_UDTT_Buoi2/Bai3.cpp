#include <iostream>
#include <vector>

using namespace std;
/*
Cài đặt chương trình thực hiện.
- Khởi tạo danh sách gồm tối thiểu 15 số thực.
- Tìm giá trị lớn nhất của danh sách bằng thuật toán được thiết kế theo chiến
lược chia để trị.
- Hiển thị kết quả.
*/

double maxValue(vector<double> danhSachSoThuc, int left, int right)
{
    if (left == right)
    {
        return danhSachSoThuc[left];
    }
    int mid = left + (right - left) / 2;
    double maxLeft = maxValue(danhSachSoThuc, left, mid);
    double maxRight = maxValue(danhSachSoThuc, mid + 1, right);
    return max(maxLeft, maxRight);
}

int main()
{
    #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    #endif
    vector <double> danhSachSoThuc = {5.5, 2.3, 9.8, 1.2, 4.4, 7.7, 6.6, 3.3, 8.8, 0.1, 11.11, 12.12, 13.13, 14.14, 15.15};
    cout << "Danh sach so thuc ban dau: " << endl;  
    for (auto &so : danhSachSoThuc)
    {
        cout << so << " ";
    }
    cout << endl;

    cout << "Gia tri lon nhat trong danh sach la: " << maxValue(danhSachSoThuc, 0, danhSachSoThuc.size() - 1) << endl;
    
    return 0;
}