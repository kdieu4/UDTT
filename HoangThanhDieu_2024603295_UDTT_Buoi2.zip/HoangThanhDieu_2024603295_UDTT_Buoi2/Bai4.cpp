#include <iostream>

using namespace std;
/*
Cài đặt chương trình thực hiện.
- Nhập số thực a và số nguyên dương n.
- Tính giá trị a mũ n bằng thuật toán được thiết kế theo chiến lược chia để trị.
- Hiển thị kết quả.
*/

double myPow(double a, int n)
{
    if (n == 0)
    {
        return 1;
    }
    if (n == 1)
    {
        return a;
    }
    double half = myPow(a, n / 2);
    if (n % 2 == 0)
    {
        return half * half;
    }
    else
    {
        return half * half * a;
    }
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    double a;
    int n;
    cout << "Nhap so thuc a: "; cin >> a;
    cout << "Nhap so nguyen duong n: "; cin >> n;
    cout << a << " mu " << n << " = " << myPow(a, n) << endl;
    return 0;
}