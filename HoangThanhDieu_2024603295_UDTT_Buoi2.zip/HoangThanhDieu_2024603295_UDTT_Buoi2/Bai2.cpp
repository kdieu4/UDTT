#include <iostream>
#include <vector>
#include <iomanip>
#include <numeric>
#include <algorithm>
using namespace std;

/*
Cài đặt chương trình thực hiện.
- Khởi tạo danh sách gồm tối thiểu 15 số thực.
- Sắp xếp danh sách theo chiều tăng dần bằng thuật toán sắp xếp trộn được thiết
kế theo chiến lược chia để trị.
- Hiển thị danh sách sau khi sắp xếp.
*/

void mergeSort(vector<double> &danhSachSoThuc, int left, int right)
{
    if (left < right)
    {
        int mid = left + (right - left) / 2;
        mergeSort(danhSachSoThuc, left, mid);
        mergeSort(danhSachSoThuc, mid + 1, right);

        vector<double> temp = danhSachSoThuc; // Tao mang tam de luu tru gia tri tam thoi
        // xuat(temp);
        int i = left, j = mid + 1, k = left;
        while (i <= mid && j <= right && k <= right)
        {
            if (temp[i] < temp[j])
            {
                danhSachSoThuc[k++] = temp[i++];
            }
            else
            {
                danhSachSoThuc[k++] = temp[j++];
            }
        }
        while (i <= mid)
        {
            danhSachSoThuc[k++] = temp[i++];
        }
        while (j <= right)
        {
            danhSachSoThuc[k++] = temp[j++];
        }
    }
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    vector <double> danhSachSoThuc = {5.5, 2.3, 9.8, 1.2, 4.4, 7.7, 6.6, 3.3, 8.8, 0.1, 11.11, 12.12, 13.13, 14.14, 15.15};
    cout << "Danh sach so thuc ban dau: " << endl;
    for (auto &so : danhSachSoThuc)
    {
        cout << so << " ";
    }

    mergeSort(danhSachSoThuc, 0, danhSachSoThuc.size() - 1);
    cout << "\nDanh sach so thuc sau khi sap xep: " << endl;
    for (auto &so : danhSachSoThuc)
    {
        cout << so << " ";
    }
    return 0;
}