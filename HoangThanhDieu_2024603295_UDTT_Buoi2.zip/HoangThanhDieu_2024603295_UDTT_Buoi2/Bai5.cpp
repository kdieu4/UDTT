#include <iostream>
#include <vector>

using namespace std;

/*
Cài đặt chương trình thực hiện.
- Khởi tạo danh sách a gồm tối thiểu 20 số thực.
- Tính tổng các số dương trong danh sách a bằng một thuật toán được thiết kế
theo chiến lược chia để trị.
- Hiển thị kết quả.
*/

double sumPositive(vector<double> a, int left, int right)
{
    if (left == right)
    {
        return a[left] > 0 ? a[left] : 0;
    }
    int mid = left + (right - left) / 2;
    return sumPositive(a, left, mid) + sumPositive(a, mid + 1, right);
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    vector<double> a = {5, -3, 2.5, -1.5, 4, -6, 7.2, -8.3, 9, -10, 11.1, -12.2, 13.3, -14.4, 15.5, -16.6, 17.7, -18.8, 19.9, -20};
    cout << "Danh sach a: ";
    for (double num : a)
    {
        cout << num << " ";
    }
    cout << endl;
    // Chia để trị để tính tổng các số dương
    cout << "Tong cac so duong trong danh sach a: " << sumPositive(a, 0, a.size() - 1) << endl;
    return 0;
}