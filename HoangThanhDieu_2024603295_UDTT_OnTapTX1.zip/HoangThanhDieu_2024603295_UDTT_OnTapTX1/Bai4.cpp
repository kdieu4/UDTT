#include <iostream>
#include <iomanip>

using namespace std;

/*
Cho danh các chuyến bay b của 1 hãng hàng không, thông tin về chuyến bay gồm
số hiệu chuyến bay (ví dụ: VN005), giá vé, số ghế ngồi.
Viết chương trình thực hiện.
- Tạo danh sách b gồm từ 6 đến 10 chuyến bay, sao cho các chuyến bay có giá vé khác
nhau đôi một (không nhập từ bàn phím, dữ liệu có tính thực tiễn).
- Hiển thị tất cả các chuyến bay có giá vé trên 700000 bằng phương pháp đệ quy.
- Tìm chuyến bay có giá vé thấp nhất bằng phương pháp chia để trị, hiển thị thông tin
chuyến bay tìm được.
- Hiển thị tất cả các phương án khác nhau để chọn ra 4 chuyến bay từ ds b (chỉ cần hiển
thị số hiệu chuyến bay) bằng phương pháp quay lui.
*/

struct ChuyenBay
{
    char soHieu[6];
    long long giaVe;
    int soGhe;
};

struct List
{
    int count;
    ChuyenBay *cb;
};

void init(List &l)
{
    l.count = 0;
    l.cb = new ChuyenBay[100];
}

bool isFull(List l)
{
    return l.count == 100;
}

void nhapChuyenBay(ChuyenBay &cb)
{
    cout << "Nhap so hieu chuyen bay: ";
    cin >> cb.soHieu;
    cout << "Nhap gia ve: ";
    cin >> cb.giaVe;
    cout << "Nhap so ghe: ";
    cin >> cb.soGhe;
}

void nhapDanhSach(List &l)
{
    cout << "Nhap so luong chuyen bay: ";
    cin >> l.count;
    for (int i = 0; i < l.count; i++)
    {
        cout << "Nhap chuyen bay thu " << i + 1 << ":\n";
        nhapChuyenBay(l.cb[i]);
    }
}

void taoDanhSach(List &l)
{
    l.cb[0] = {"VN123", 1500000, 120};
    l.cb[1] = {"VJ456", 800000, 180};
    l.cb[2] = {"QH789", 600000, 200};
    l.cb[3] = {"LT101", 900000, 320};
    l.cb[4] = {"VH102", 850000, 240};
    l.cb[5] = {"KS103", 700000, 220};
    l.count = 5;
}

void xuatDanhSach(List l)
{
    cout << setw(10) << left << "So hieu" << setw(15) << "Gia ve" << setw(10) << "So ghe" << endl;
    for (int i = 0; i <= l.count; i++)
    {
        cout << setw(10) << left << l.cb[i].soHieu << setw(15) << l.cb[i].giaVe << setw(10) << l.cb[i].soGhe << endl;
    }
}

void hienThiChuyenBayGiaVeTren700000(List l, int index)
{
    if (index == l.count)
        return;
    if (l.cb[index].giaVe > 700000)
    {
        cout << setw(10) << left << l.cb[index].soHieu << setw(15) << l.cb[index].giaVe << setw(10) << l.cb[index].soGhe << endl;
    }
    hienThiChuyenBayGiaVeTren700000(l, index + 1);
}

ChuyenBay chuyenBayGiaVeThapNhat(List l, int left, int right)
{
    if (left == right)
        return l.cb[left];
    int mid = (left + right) / 2;
    ChuyenBay cb1 = chuyenBayGiaVeThapNhat(l, left, mid);
    ChuyenBay cb2 = chuyenBayGiaVeThapNhat(l, mid + 1, right);
    return (cb1.giaVe < cb2.giaVe) ? cb1 : cb2;
}

void timChuyenBayGiaVeThapNhat(List l, int left, int right)
{
    ChuyenBay ChuyenBayGiaVeThapNhat = chuyenBayGiaVeThapNhat(l, left, right);
    cout << setw(10) << ChuyenBayGiaVeThapNhat.soHieu << setw(15) << ChuyenBayGiaVeThapNhat.giaVe << setw(10) << ChuyenBayGiaVeThapNhat.soGhe << endl;
}

void show(List L, int k, int *x)
{
    for (int i = 1; i <= k; i++)
    {
        cout << L.cb[x[i] - 1].soHieu << " ";
        // cout << x[i] << " \n";
    }
    cout << endl;
}

void backTrack(List &l, int k, int pos, int *x)
{
    for (int i = 1; i <= l.count + 1; i++)
    {
        // cout << "x[" << pos - 1 << "] = " << x[pos - 1] << endl;
        if (i > x[pos - 1] && i <= l.count + 1 - k + pos)
        {
            x[pos] = i;
            // cout << "Da chon: x[" << pos << "] = " << i << endl;
            if (pos == k)
            {
                show(l, k, x);
            }
            else
            {
                backTrack(l, k, pos + 1, x);
            }
        }
    }
}

void myTry(List &l, int k, int pos)
{
    int *x = new int[k + 1];
    for (int i = 0; i <= k; i++)
    {
        x[i] = 0;
    }
    backTrack(l, k, pos, x);
    delete[] x;
}

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    List b;
    init(b);
    taoDanhSach(b);
    cout << "Danh sach chuyen bay: \n";
    xuatDanhSach(b);

    cout << "Cac chuyen bay co gia ve tren 700000: \n";
    hienThiChuyenBayGiaVeTren700000(b, 0);

    cout << "Chuyen bay co gia ve thap nhat: \n";
    timChuyenBayGiaVeThapNhat(b, 0, b.count);

    cout << "Cach chon 4 chuyen bay tu danh sach: \n";

    myTry(b, 4, 1);

    return 0;
}