#include <iostream>
#define MAX 100
using namespace std;

/*
Cho tập S gồm 7 ký tự S = {‘A’, ‘B’, ‘C’, ‘D’, ‘E’, ‘F’, ‘G’}. Hãy liệt kê các cách
lấy 6 ký tự khác nhau từ tập S nói trên, cho biết số cách lấy. Sử dụng phương pháp sinh,
sau đó sử dụng thuật toán quay lui.
*/

void view_config(const char s[], const int x[], int k)
{
    for (int i = 0; i < k; i++)
    {
        cout << s[x[i]] << " ";
    }
    cout << endl;
}

void next_config(int x[], int k, int i)
{
    x[i]++;
    i++;
    while (i < k)
    {
        x[i] = x[i - 1] + 1;
        i++;
    }
}

void list_configs(const char s[], int n, int k)
{
    int i = 0, cnt = 0;
    int x[MAX] = {0};
    for (int i = 0; i < k; i++)
    {
        x[i] = i;
    }
    do
    {
        cnt++;
        view_config(s, x, k);
        i = k - 1;
        // cout << i << endl;
        while (i >= 0 && x[i] == n - k + i)
        {
            i--;
        }
        if (i >= 0)
        {
            next_config(x, k, i);
        }
    } while (i >= 0);
    cout << "Số cách lấy: " << cnt << endl;
}

void show(const char s[], const int x[], int k)
{
    for (int i = 1; i <= k; i++)
    {
        cout << s[x[i]] << " ";
    }
    cout << endl;
}

int x[MAX] = {0};
void myTry(const char s[], int n, int k, int pos, int &cnt)
{
    for (int i = 1; i <= n; i++)
    {
        if (i > x[pos - 1] && i <= n - k + pos)
        {
            x[pos] = i;
            if (pos == k)
            {
                cnt++;
                show(s, x, k);
            }
            else
            {
                myTry(s, n, k, pos + 1, cnt);
            }
        }
    }
}

void backtrack(const char s[], int n, int k, int pos)
{
    int cnt = 0;
    myTry(s, n, k, pos, cnt);
    cout << "Số cách lấy: " << cnt << endl;
}

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    char s[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
    cout << "Các cách láy 6 ký tự khác nhau từ tập S bằng phương pháp sinh: \n";
    list_configs(s, 7, 6);
    char _s[] = {' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G'};
    cout << "Các cách lấy 6 ký tự khác nhau từ tập S bằng phương pháp quay lui:  \n";
    backtrack(_s, 7, 6, 1);
    return 0;
}