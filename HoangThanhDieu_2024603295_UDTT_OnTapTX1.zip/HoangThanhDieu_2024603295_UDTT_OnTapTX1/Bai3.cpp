#include <iostream>

using namespace std;

/*
Cài đặt chương trình cho bài toán tháp Hà Nội bằng thuật toán đệ quy và khử đệ
quy.
*/

// De quy
void hanoiTowerRecursion(int n, char A, char B, char C)
{
    if (n == 1)
    {
        cout << "Chuyển 1 đĩa từ " << A << " sang " << C << endl;
        return;
    }
    hanoiTowerRecursion(n - 1, A, C, B); // chuyen n-1 dia tu A sang B
    hanoiTowerRecursion(1, A, B, C);     // chuyen dia con lai tu A sang C
    hanoiTowerRecursion(n - 1, B, A, C); // chuyen n - 1 dia tu B sang C
}

struct Call
{
    int n;
    char A, B, C;
};

struct Stack
{
    int top;
    Call *e;
};

void init(Stack &s)
{
    s.top = -1;
    s.e = new Call[100];
}

void push(Stack &s, Call c)
{
    s.e[++s.top] = c;
}

void pop(Stack &s, Call &c)
{
    c = s.e[s.top--];
}

bool empty(Stack &s)
{
    return s.top == -1;
}

void hanoiTowerStack(Stack &s, Call first_call)
{
    push(s, first_call);
    // cout << s.e[s.top].n << endl;
    while (!empty(s))
    {
        Call call;
        pop(s, call);
        if (call.n == 1)
        {
            cout << "Chuyen 1 dia tu " << call.A << " sang " << call.C << endl;
        }
        else
        {
            Call call_1 = {(call.n - 1), call.A, call.C, call.B};
            Call call_2 = {1, call.A, call.B, call.C};
            Call call_3 = {(call.n - 1), call.B, call.A, call.C};

            push(s, call_3);
            push(s, call_2);
            push(s, call_1);
        }
    }
}

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cout << "Cách giải bài toán tháp Hà Nội bằng phương pháp đệ quy: \n";
    hanoiTowerRecursion(3, 'A', 'B', 'C');
    // cout << "hehe" << endl;

    cout << "Cách giải bài toán tháp Hà Nội bằng phương pháp khử đệ quy: " << endl;
    Stack s;
    init(s);
    Call first_call = {3, 'A', 'B', 'C'};
    hanoiTowerStack(s, first_call);

    return 0;
}