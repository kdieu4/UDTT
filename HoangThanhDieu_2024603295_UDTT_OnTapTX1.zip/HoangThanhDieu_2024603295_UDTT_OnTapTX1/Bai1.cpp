#include <iostream>
using namespace std;
#define MAX 100
/*
Cho 4 chiếc ghế gán nhãn lần lượt là {‘A’, ‘B’, ‘C’, ‘D’} và 4 người gồm
{tung, cuc, truc, mai}. Hãy liệt kê tất cả các cách xếp 4 người vào 4 ghế, mỗi cách xếp
cần chỉ rõ vị trí ngồi của mỗi người, cho biết tổng số cách xếp. Sử dụng phương pháp
sinh, sau đó sử dụng thuật toán quay lui.
*/

void view_config(string nguoi[], char ghe[], int x[], int n)
{
    // In ra một cách xếp
    for (int i = 0; i < n; i++)
        cout << nguoi[i] << " ngồi ghế " << ghe[x[i]] << endl;
    cout << endl;
}

void next_config(int x[], int n, int i)
{
    // Sinh cấu hình tiếp theo
    int j = n - 1;
    while (x[i - 1] > x[j])
        j--;
    swap(x[i - 1], x[j]);
    int r = n - 1;
    int s = i;
    while (s < r)
    {
        swap(x[s], x[r]);
        s++;
        r--;
    }
}

void list_configs(string nguoi[], char ghe[], int n)
{
    // In ra các cách xếp
    int i;
    int cnt = 1;
    int x[MAX] = {0};
    for (int i = 0; i < n; i++)
    {
        x[i] = i;
    }
    do
    {
        i = n - 1;
        view_config(nguoi, ghe, x, n);
        while (i > 0 && x[i - 1] > x[i])
        {
            i--;
        }

        if (i > 0)
        {
            cnt++;
            next_config(x, n, i);
        }
    } while (i > 0);
    cout << "Tong so cach xep: " << cnt << endl;
}

void show(const string nguoi[], const char ghe[], int x[], int n)
{
    for (int i = 0; i < n; i++)
        cout << nguoi[i] << " ngồi ghế " << ghe[x[i]] << endl;
    cout << endl;
}

int mark[MAX] = {0};
int x[MAX] = {0};
int cnt;
void myTry(const string nguoi[], const char ghe[], int k, int n)
{
    for (int i = 0; i < n; i++)
    {
        if (mark[i] == 0)
        {
            x[k] = i;
            mark[i] = 1;
            if (k == n - 1)
            {
                show(nguoi, ghe, x, n);
                cnt++;
            }
            else
            {
                myTry(nguoi, ghe, k + 1, n);
            }
            mark[i] = 0;
        }
    }
}

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    char ghe[4] = {'A', 'B', 'C', 'D'};
    string nguoi[4] = {"Tùng", "Cúc", "Trúc", "Mai"};
    cout << "Cac cach xep 4 nguoi vao 4 ghe su dung phuong phap sinh la: " << endl;
    list_configs(nguoi, ghe, 4);

    cout << "Cac cach xep 4 nguoi vao 4 ghe su dung phuong phap quay lui la: " << endl;
    myTry(nguoi, ghe, 0, 4);
    cout << "Tong so cach xep: " << cnt << endl;
    return 0;
}