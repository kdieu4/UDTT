#include <iostream>
#include <ctime>
#include <iomanip>
#include <chrono>

using namespace std;
using namespace std::chrono;
using TimePoint = system_clock::time_point;

#define MAX 100

/*
Cho danh sách công việc c cần thực hiện trong ngày của một công ty, thông tin
về công việc gồm mã công việc, thời gian bắt đầu, thời gian thực hiện (phút/giờ).
Viết chương trình thực hiện.
- Tạo danh sách c gồm từ 6 đến 10 công việc (không nhập từ bàn phím, dữ liệu có tính
thực tiễn).
- Hiển thị danh sách các công việc trong danh sách c theo thứ tự ngược lại bằng phương
pháp đệ quy.
- Hiển thị tất cả các phương án lấy ra 5 công việc từ danh sách c (chỉ cần hiển thị mã
công việc) bằng phương pháp sinh.
*/

struct CongViec
{
    char maCV[10];
    char thoiGianBD[10];
    int thoiGianThucHienPhut;
};

struct List
{
    int count;
    CongViec *cv;
};

void init(List &l)
{
    l.count = -1;
    l.cv = new CongViec[MAX];
}

void taoDS(List &l)
{
    l.count = 7;
    l.cv[0] = {"CV01", "08:00", 30};  // Họp nhanh đầu ngày (Daily stand-up)
    l.cv[1] = {"CV02", "08:30", 45};  // Kiểm tra và trả lời email quan trọng
    l.cv[2] = {"CV03", "09:15", 150}; // Lập trình tính năng A cho dự án X
    l.cv[3] = {"CV04", "11:45", 60};  // Ăn trưa và nghỉ ngơi
    l.cv[4] = {"CV05", "13:00", 90};  // Họp với khách hàng B
    l.cv[5] = {"CV06", "14:30", 120}; // Sửa lỗi (bug) phát sinh trên hệ thống
    l.cv[6] = {"CV07", "16:30", 30};  // Viết báo cáo tiến độ công việc ngày
    l.cv[7] = {"CV08", "17:00", 15};  // Lên kế hoạch cho ngày làm việc tiếp theo
}

void xuatDS(List &l)
{
    cout << setw(5) << left << "STT";
    cout << setw(10) << "Ma CV";
    cout << setw(10) << "TGBD";
    cout << setw(10) << "TGTH" << endl;
    for (int i = 0; i <= l.count; i++)
    {
        cout << setw(5) << i + 1;
        cout << setw(10) << l.cv[i].maCV;
        cout << setw(10) << l.cv[i].thoiGianBD;
        cout << setw(10) << l.cv[i].thoiGianThucHienPhut << endl;
    }
}

void xuatDSNguoc(List &l, int index)
{
    if (index == l.count)
    {
        return;
    }
    else 
    {
        cout << setw(5) << index + 1;
        cout << setw(10) << l.cv[index].maCV;
        cout << setw(10) << l.cv[index].thoiGianBD;
        cout << setw(10) << l.cv[index].thoiGianThucHienPhut << endl;
        return xuatDSNguoc(l, index - 1);
    }
}

void view_config(List &l, int k, int *x){
    for (int i = 0; i < k; i++){
        cout << l.cv[x[i]].maCV << " ";
    }
    cout << endl;
}

void list_configs(List &l, int k){
    int *x = new int[k];
    for (int i = 0; i < k; i++){
        x[i] = i;
    }
    int i;
    do {
        view_config(l, k, x);
        i = k - 1;
        while (i >= 0 && x[i] == l.count - k + i + 1){
            i--;
        }
        if (i >= 0){
            x[i]++;
            for (int j = i + 1; j < k; j++){
                x[j] = x[j - 1] + 1;
            }
        }
    } while (i >= 0);
    delete[] x;
}

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    List l;
    init(l);
    cout << "Danh sach cong viec: \n";
    taoDS(l);
    xuatDS(l);

    cout << "Danh sach cong viec nguoc lai: \n";
    xuatDSNguoc(l, l.count);


    cout << "Phuong an lay ra 5 cong viec: \n";
    list_configs(l, 5);
    return 0;
}